package com.example.demoauthtwo;

import java.util.LinkedHashMap;
import java.util.Map;

public class DB {

    static Map<String, User> database = new LinkedHashMap<String, User>();

    public static void insert (String key, User value) {

        database.put(key, value);
    }

    public static User fetch( String key) {
        return database.get(key);

    }

}