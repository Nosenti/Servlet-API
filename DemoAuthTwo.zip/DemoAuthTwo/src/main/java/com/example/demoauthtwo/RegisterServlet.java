package com.example.demoauthtwo;

import java.io.IOException;

import javax.json.bind.JsonbBuilder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet(name = "RegisterServlet" , urlPatterns = "/register" )
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {

            String username = req.getParameter("username");
            String password = req.getParameter("password");
            String firstname = req.getParameter("firstname");
            String lastname = req.getParameter("lastname");
            String phone = req.getParameter("phone");
            int age =Integer.parseInt(req.getParameter("age"));
            String gender = req.getParameter("gender");
            String account = req.getParameter("role");


            if(	username == null ||
                    password == null ||
                    firstname == null ||
                    lastname == null ||
                   gender == null ||
                    phone == null ||
                    account == null ||
                    username.isEmpty() ||
                    password.isEmpty()	||
                    firstname.isEmpty() ||
                    lastname.isEmpty() ||
                    phone.isEmpty()||
                    gender.isEmpty()||
                    account.isEmpty()
            )
            {

                resp.setContentType("application/json");
                resp.setCharacterEncoding("UTF-8");
                resp.getWriter().println(JsonbBuilder.create().toJson( "all field are required!!"));
//                resp.getWriter().println(gson.toJson(new ApiResponse<Object>(400, "all field are required!!", null)));
                return;
            }


            if (account.equals("Admin")) {

                Admin admin = new Admin();

                admin.setUsername(username);
                admin.setPassword(password);
                admin.setFirstname(firstname);
                admin.setLastname(lastname);
                admin.setAge(age);
                admin.setPhone(phone);
                admin.setGender(gender);


                String isRegistered = admin.Register();

                if(isRegistered =="User Registered") {

                    resp.setContentType("application/json");
                    resp.setCharacterEncoding("UTF-8");
                    resp.getWriter().println(JsonbBuilder.create().toJson( admin));

                }
                else {
                    resp.setContentType("application/json");
                    resp.setCharacterEncoding("UTF-8");
                    resp.getWriter().println(JsonbBuilder.create().toJson("User Already exists"));

                }
            }
            else if(account.equals("Guest")) {
                System.out.println("inside guest");

               Guest guest = new Guest();

                guest.setUsername(username);
                guest.setPassword(password);
                guest.setFirstname(firstname);
                guest.setLastname(lastname);
                guest.setAge(age);
                guest.setPhone(phone);
                guest.setGender(gender);

                String isRegistered = guest.Register();

                if(isRegistered =="User Registered") {

                    resp.setContentType("application/json");
                    resp.setCharacterEncoding("UTF-8");
                    //resp.getWriter().println(JsonbBuilder.create().toJson(new ApiResponse<Guest>(201, "Successfully registered an account", guest)));
                    String jsonObject = JsonbBuilder.create().toJson(guest);
                    System.out.println(">>> " + jsonObject);
                    resp.setStatus(201);
                    resp.getWriter().println(jsonObject);
                }
                else {
                    resp.setContentType("application/json");
                    resp.setCharacterEncoding("UTF-8");
                    resp.getWriter().println(JsonbBuilder.create().toJson("400"));


                }

            }
            else {

                resp.setContentType("application/json");
                resp.setCharacterEncoding("UTF-8");
                resp.getWriter().println(JsonbBuilder.create().toJson( "role not allowed"));
            }

        } catch (Exception e) {

            System.out.println(e.getMessage());

            resp.setContentType("application/json");
            resp.setCharacterEncoding("UTF-8");
            resp.getWriter().println(JsonbBuilder.create().toJson("Server error"));
        }


    }

}

