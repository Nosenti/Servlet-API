package com.example.demoauthtwo;

import java.io.IOException;

import javax.json.bind.JsonbBuilder;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name ="LoginServlet" ,urlPatterns = "/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


        try {

            String username = req.getParameter("username");
            String password = req.getParameter("password");

            User user = DB.fetch(username);

            boolean isLogin = user.Login(username, password);


            if(!isLogin) {
                resp.setContentType("application/json");
                resp.setCharacterEncoding("UTF-8");
                String jsonObject = JsonbBuilder.create().toJson("Login failed");
                System.out.println(">>> " + jsonObject);
                resp.setStatus(400);
                resp.getWriter().println(jsonObject);
            }
            else {
                resp.setContentType("application/json");
                resp.setCharacterEncoding("UTF-8");
                String jsonObject = JsonbBuilder.create().toJson(user);
                System.out.println(">>> " + jsonObject);
                resp.setStatus(200);
                resp.getWriter().println(jsonObject);
            }

        } catch (Exception e) {
            resp.setContentType("application/json");
            resp.setCharacterEncoding("UTF-8");
            resp.getWriter().println(JsonbBuilder.create().toJson( e));
        }

    }

}
