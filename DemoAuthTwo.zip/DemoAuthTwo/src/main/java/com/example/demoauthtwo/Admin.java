package com.example.demoauthtwo;

public class Admin extends User{



    @Override
    public String getRole() {

        return "Admin";
    }

    @Override
    public String Register() {

        if(! this.checkPassword(this.password) && this.password.length() !=10) {

            return "Password rules not met";

        }

        if(!DB.database.containsKey(this.username)) {

            String passwordEncrypted= "";

            for(int i =this.password.length() ; i > 0 ; i--) {

                passwordEncrypted += this.password.substring(i-1, i);
            }

            passwordEncrypted += this.getAgeString();
            passwordEncrypted = "**" + passwordEncrypted + "**";

            this.setPassword(passwordEncrypted);

            DB.insert(this.username, this);

            return "User Registered";
        }
        return "User already exist";
    }

    @Override
    public Boolean Login(String username, String password) {

        if(DB.database.containsKey(username)) {

            User user = DB.fetch(username);

            String passwordEncrypted = user.getPassword();
            //  **     oolleh     030**
            passwordEncrypted = passwordEncrypted.substring(2,passwordEncrypted.length()-5);

            String passwordDecrypted = "";


            // reverse
            for(int i = passwordEncrypted.length() ; i > 0 ; i--) {

                passwordDecrypted += passwordEncrypted.substring(i-1, i);
            }

            //
            if (passwordDecrypted.equals(password)) {

                return true;

            }

        }
        return false;
    }

}
