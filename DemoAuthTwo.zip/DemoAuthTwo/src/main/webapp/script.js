const signupForm = document.querySelector('.signup-form');


signupForm.addEventListener("submit", async(e) => {
    e.preventDefault();

    var s = document.querySelectorAll('input[name="gender"]');
    var gen;
    console.log('s: ', s)
    for(i = 0; i < s.length; i++) {
        if(s[i].checked){
            console.log(s[i].value)
            gen = s[i].value;
        }
    }

    const username = signupForm.username.value;
    const password = signupForm.password.value;
    const firstname = signupForm.firstname.value;
    const lastname = signupForm.lastname.value;
    const age = signupForm.age.value;
    const gender = gen;
    const phone = signupForm.phone.value;
    const role = document.querySelector('#roles').value;

    const data = {
        username,
        password,
        firstname,
        lastname,
        age,
        gender,
        phone,
        role
    }

    console.log('dt_: ', data)


    var formData = [];
    for (var property in data) {
        var encodedKey = encodeURIComponent(property);
        var encodedValue = encodeURIComponent(data[property]);
        formData.push(encodedKey + "=" + encodedValue);
    }
    formData = formData.join("&");

    console.log('formData: ', formData);

    const res = await fetch("http://localhost:8080/DemoAuthTwo/register", {

        method: "POST",
        headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
        body: formData

    });
    const user = await res.json();
    console.log('user__', user)

    if(user.username != undefined){
        location.href="/DemoAuthTwo/login.html";
    }
    else{
        alert("Registration error");
    }

} );



