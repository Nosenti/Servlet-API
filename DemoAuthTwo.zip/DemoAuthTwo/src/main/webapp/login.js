const loginForm = document.querySelector('.login-form');

loginForm.addEventListener("submit", async(e) => {
    console.log('event listender called!')
    e.preventDefault();

    const username = loginForm.username.value;
    const password = loginForm.password.value;

    const data = {
        username,
        password,
    }
    var formBody = [];
    for (var property in data) {
        var encodedKey = encodeURIComponent(property);
        var encodedValue = encodeURIComponent(data[property]);
        formBody.push(encodedKey + "=" + encodedValue);
    }
    formBody = formBody.join("&");

    console.log(formBody);

    const res = await fetch("http://localhost:8080/DemoAuthTwo/login", {

        method: "POST",
        headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
        body: formBody

    });
    const user = await res.json();

    if(user.username != undefined){
        console.log('Login success')
        alert("login success");
    }
    else{
        alert("login failed");
    }

} );